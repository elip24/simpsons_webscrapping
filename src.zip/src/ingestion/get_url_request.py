from urllib.parse import urlsplit, urlunsplit, unquote
from typing import List, Dict, Set, Tuple
import math, requests
from bs4 import BeautifulSoup
from requests import session

from src.ingestion.page_configurations import (
    headers, API_URL, BASE_URL, make_payload,
    DEFAULT_PAGE_ID, DEFAULT_NEWS_TYPE
)
from parse_api import get_urls_and_dates

def warm_cookies(session: requests.Session, referer: str) -> None:
    r = session.get(referer, headers=headers, timeout=30)
    r.raise_for_status()

def post_page(session: requests.Session, page_id: str, news_type: str, page: int, page_size: int = 100):
    payload = make_payload(page_id, news_type, take=page_size)
    payload["page"] = page
    payload["pageSize"] = str(page_size)
    payload["skip"] = str((page - 1) * page_size)
    payload["take"] = str(page_size)
    r = session.post(API_URL, data=payload, headers=headers, timeout=30)
    r.raise_for_status()
    j = r.json()
    return j.get("NewsItems", [])

def get_guid_again(session: requests.Session) -> str:
    html = session.get(url=BASE_URL, headers=headers, timeout=30).text
    soup = BeautifulSoup(html, "html.parser")
    a = soup.select_one('[aria-label="Matter Highlights"]')
    if not a or "href" not in a.attrs:
        raise RuntimeError("Could not recover news_type from listing page")
    return a["href"].split("=", 1)[1]

def _normalize(u: str) -> str:
    s = urlsplit(u)
    # normalize only the path; keep query (Culture=en) intact
    return urlunsplit((s.scheme, s.netloc, unquote(s.path).rstrip("/"), s.query, ""))
list_of_raw_url=[
"https://www.stblaw.com/about-us/news/view/2025/08/22/marriott-international-completes-$1.5-billion-notes-offering?Culture=en",
"https://www.stblaw.com/about-us/news/view/2015/02/11/blackstone-capital-partners-and-blackstone-energy-partners-form-new-utility-and-heavy-equipment-platform?Culture=en",
"https://www.stblaw.com/about-us/news/view/2014/10/23/simpson-thacher-represents-deutsche-bank-crédit-agricole-j.p.-morgan-merrill-lynch-and-the-royal-bank-of-scotland-in-us$500-million-debt-offering-by-korea-land-housing-corporation?Culture=en",
"https://www.stblaw.com/about-us/news/view/2014/05/27/simpson-thacher-represents-schulze-global-in-raising-$85-million-for-first-ever-ethiopia-private-equity-fund?Culture=en",
"https://www.stblaw.com/about-us/news/view/2013/05/16/simpson-thacher-wins-appeal-of-verdict-for-client-mohammad-al-saleh-in-iraqi-war-defense-contracts-case?Culture=en",
"https://www.stblaw.com/about-us/news/view/2013/05/10/simpson-thacher-represents-underwriters-in-$1-0-billion-investment-grade-notes-offering-by-texas-instruments-incorporated?Culture=en",
"https://www.stblaw.com/about-us/news/view/2013/02/01/simpson-thacher-obtains-dismissal-of-shareholder-lawsuit-against-cvc?Culture=en",
"https://www.stblaw.com/about-us/news/view/2012/12/21/simpson-thacher-represents-igloo-holdings-corporation-in-$350-million-offering-of-senior-pik-toggle-notes?Culture=en",
"https://www.stblaw.com/about-us/news/view/2012/11/06/simpson-thacher-wins-exoneration-of-30-year-old-murder-charge-for-habeas-petitioner?Culture=en",
"https://www.stblaw.com/about-us/news/view/2012/10/03/firm-represents-underwriters-in-$105-million-preferred-stock-offering-by-the-gabelli-equity-trust-inc-?Culture=en",
]
def get_url_request():
    with requests.session() as session:
        warm_cookies(session, referer=BASE_URL)
        news_type = DEFAULT_NEWS_TYPE
        deduped_rows = set()
        all_meta = []
        for p in range(1,10):
            response=post_page(session,DEFAULT_PAGE_ID, news_type,page=p,page_size=1000)

            if response[0].get("NewsTypeGuid")!=DEFAULT_NEWS_TYPE:
                print("Change the Default news type. For THIS page bringing everything.")
                new_news_type=get_guid_again(session)
                news_type=new_news_type
            for row in get_urls_and_dates(response):
                url=row["url"] if row.get("url") in list_of_raw_url else None
                if url not in list_of_raw_url:
                    continue

                if url in deduped_rows:
                    continue

                deduped_rows.add(url)
                all_meta.append(row)
    return deduped_rows,all_meta
