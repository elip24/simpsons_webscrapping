from urllib.parse import urlsplit, urlunsplit, unquote
from typing import List, Dict, Set, Tuple
import math, requests
from bs4 import BeautifulSoup

from src.ingestion.page_configurations import (
    headers, API_URL, BASE_URL, make_payload,
    DEFAULT_PAGE_ID, DEFAULT_NEWS_TYPE
)
from parse_api import get_urls_and_dates

def warm_cookies(session: requests.Session, referer: str) -> None:
    r = session.get(referer, headers=headers, timeout=30)
    r.raise_for_status()

def post_page(session: requests.Session, page_id: str, news_type: str, page: int, page_size: int = 100):
    payload = make_payload(page_id, news_type, take=page_size)
    payload["page"] = str(page)
    payload["pageSize"] = str(page_size)
    payload["skip"] = str((page - 1) * page_size)
    payload["take"] = str(page_size)
    r = session.post(API_URL, data=payload, headers=headers, timeout=30)
    r.raise_for_status()
    j = r.json()
    return int(j.get("NewsItemsCount", 0)), j.get("NewsItems", []) or []

def get_guid_and_id_again(session: requests.Session) -> Tuple[str, str]:
    html = session.get(url=BASE_URL, headers=headers, timeout=30).text
    soup = BeautifulSoup(html, "html.parser")
    pid = soup.select_one("#actual-page-id")
    a = soup.select_one('[aria-label="Matter Highlights"]')
    if not pid or not pid.has_attr("value") or not a or "href" not in a.attrs:
        raise RuntimeError("Could not recover page_id/news_type from listing page")
    return pid["value"], a["href"].split("=", 1)[1]

def _normalize(u: str) -> str:
    s = urlsplit(u)
    # normalize only the path; keep query (Culture=en) intact
    return urlunsplit((s.scheme, s.netloc, unquote(s.path).rstrip("/"), s.query, ""))

def get_url_request(page_size: int = 100) -> Tuple[List[Dict], List[str], Set[str], Dict[str, Dict]]:
    # ---- whitelist you care about ----
    wanted_raw = [
        "https://www.stblaw.com/about-us/news/view/2003/06/01/new-york-court-of-appeals-decision-in-campaign-for-fiscal-equity-v-the-state-of-new-york?Culture=en",
    ]
    wanted_norm: Set[str] = {_normalize(u) for u in wanted_raw}

    deduped_items: List[Dict] = []   # only the wanted ones go here
    seen_norm: Set[str] = set()

    def paginate_collect(session: requests.Session, page_id: str, news_type: str):
        nonlocal deduped_items, seen_norm
        warm_cookies(session, f"{BASE_URL}?newsType={news_type}")

        total, rows = post_page(session, page_id, news_type, page=1, page_size=page_size)
        if total == 0 and not rows:
            return

        last_page = max(1, math.ceil(total / page_size))

        def maybe_take(items):
            for item in get_urls_and_dates(items):
                u = item["url"]
                nu = _normalize(u)
                if nu in wanted_norm and nu not in seen_norm:
                    seen_norm.add(nu)
                    deduped_items.append(item)

        # page 1
        maybe_take(rows)

        # pages 2..last
        for p in range(2, last_page + 1):
            _, rows = post_page(session, page_id, news_type, page=p, page_size=page_size)
            if not rows:
                break
            maybe_take(rows)

            # early exit if we already got them all
            if len(seen_norm) == len(wanted_norm):
                break

    with requests.Session() as session:
        paginate_collect(session, DEFAULT_PAGE_ID, DEFAULT_NEWS_TYPE)
        if len(seen_norm) < len(wanted_norm):
            fresh_page_id, fresh_news_type = get_guid_and_id_again(session)
            paginate_collect(session, fresh_page_id, fresh_news_type)

    # Build return structures **only for the wanted URLs** we actually found
    urls_in_order: List[str] = [x["url"] for x in deduped_items]  # in API/listing order
    url_set: Set[str] = set(urls_in_order)
    url_to_meta: Dict[str, Dict] = {x["url"]: x for x in deduped_items}

    return deduped_items, urls_in_order, url_set, url_to_meta
