# src/ingestion/news_only.py
import asyncio
import json
from typing import Any, Dict, List, Optional, Tuple

import httpx
from bs4 import BeautifulSoup

from src.ingestion.page_configurations import headers

NEWS_LIST = "https://www.stblaw.com/about-us/news?Culture=en"
DESKTOP_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/126.0.0.0 Safari/537.36"
)
async def warm_cookies_httpx(client: httpx.AsyncClient) -> None:
    # Set Culture cookie explicitly (domain-wide) and use a solid UA
    client.headers.update({"User-Agent": DESKTOP_UA, "Accept-Language": "en-US,en;q=0.9"})
    client.cookies.set("Culture", "en", domain=".stblaw.com", path="/")

    # Hit the listing twice to let any server-side cookies settle
    for _ in range(2):
        r = await client.get(NEWS_LIST, timeout=30)
        r.raise_for_status()

def _looks_like_article(soup: BeautifulSoup) -> bool:
    # Article pages have #news-content. Landing typically has H1 = "News & Events"
    if soup.select("#news-content"):
        return True
    h1 = soup.find("h1")
    return bool(h1 and h1.get_text(strip=True) != "News & Events")

async def fetch_html(client: httpx.AsyncClient, url: str) -> str:
    hdrs = {
        "User-Agent": DESKTOP_UA,
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": NEWS_LIST,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
    }
    r = await client.get(url, headers=hdrs, timeout=30)
    r.raise_for_status()
    return r.text


def _collect_news_articles(objs: List[Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []

    def is_news_type(t) -> bool:
        if isinstance(t, str):
            return t == "NewsArticle" or t.endswith("NewsArticle")
        if isinstance(t, list):
            return any(is_news_type(x) for x in t)
        return False

    def walk(o):
        if isinstance(o, dict):
            if is_news_type(o.get("@type")):
                out.append(o)
            for v in o.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(o, list):
            for it in o:
                walk(it)

    for obj in objs:
        walk(obj)
    return out

def parse_json_ld(soup: BeautifulSoup) -> Optional[Dict[str, Any]]:
    scripts = soup.find_all("script", attrs={"type": "application/ld+json"})
    parsed: List[Any] = []
    for s in scripts:
        try:
            txt = s.string or s.get_text() or ""
            if not txt.strip():
                continue
            obj = json.loads(txt)
            parsed.extend(obj if isinstance(obj, list) else [obj])
        except Exception:
            continue
    news = _collect_news_articles(parsed)
    return news[0] if news else None

def sel_all_text(soup: BeautifulSoup, selector: str) -> List[str]:
    return [e.get_text(strip=True) for e in soup.select(selector)]

def sel_all_attr(soup: BeautifulSoup, selector: str, attr: str) -> List[Optional[str]]:
    vals = []
    for e in soup.select(selector):
        v = e.get(attr)
        if v and v.startswith("/"):
            v = "https://www.stblaw.com" + v
        vals.append(v)
    return vals

def extract_article_text(soup: BeautifulSoup) -> str:
    ps = soup.select("#news-content .show-when-reading-inner p")
    print(ps)
    if not ps:
        ps = soup.select("#news-content .show-when-reading-inner")
    return "\n\n".join(p.get_text(strip=True) for p in ps if p.get_text(strip=True))

def get_practices(soup: BeautifulSoup) -> List[str]:
    return sel_all_text(soup, "#tags-list-practices a")

def get_industries(soup: BeautifulSoup) -> List[str]:
    return sel_all_text(soup, "#tags-list-industries a")

def get_lawyer_names_and_links(soup: BeautifulSoup) -> Tuple[List[str], List[Optional[str]]]:
    names = sel_all_text(soup, "#tags-list-employees .bio a.name")
    hrefs = sel_all_attr(soup, "#tags-list-employees .bio a.name", "href")
    return names, hrefs

async def get_news_articles_async(client: httpx.AsyncClient, start_url: str, meta: Dict[str, Any] | None = None) -> Dict[str, Any]:
    await warm_cookies_httpx(client)
    html = await fetch_html(client, start_url)
    soup = BeautifulSoup(html, "html.parser")
    if not _looks_like_article(soup):
        await warm_cookies_httpx(client)
        html = await fetch_html(client, start_url)
        soup = BeautifulSoup(html, "html.parser")

    doc = parse_json_ld(soup)
    datemodified = None
    lawyer_names: List[str] = []
    lawyer_links: List[Optional[str]] = []

    if doc:
        datemodified = doc.get("dateModified") or doc.get("datePublished")
        authors = doc.get("author") or []
        if isinstance(authors, dict):
            authors = [authors]
        for a in authors:
            if isinstance(a, dict):
                n = a.get("name")
                u = a.get("url")
                if n: lawyer_names.append(n)
                if u: lawyer_links.append(u)
            elif isinstance(a, str):
                lawyer_names.append(a.strip())

    text = extract_article_text(soup)
    practices = get_practices(soup)
    industries = get_industries(soup)

    if not lawyer_names:
        lawyer_names, lawyer_links = get_lawyer_names_and_links(soup)

    all_news: Dict[str, Any] = {
        "dateModified": datemodified,
        "url": start_url,
        "practices": practices,
        "industries": industries,
        "lawyer_names": lawyer_names,
        "lawyer_links": lawyer_links,
        "text": text,
    }
    if meta:
        all_news.update(meta)
    return all_news

async def scrape_many(urls: List[str]) -> List[Dict[str, Any]]:
    async with httpx.AsyncClient(follow_redirects=True) as client:
        await warm_cookies_httpx(client)
        results = await asyncio.gather(*(get_news_articles_async(client, u) for u in urls))
    return results

if __name__ == "__main__":
    test_urls = [
        "https://www.stblaw.com/about-us/news/view/2025/06/09/mobilization-for-justice-and-simpson-thacher-secure-victory-with-sdny-denying-nycdoe-s-motion-to-dismiss-class-action-targeting-systemic-failure-to-provide-timely-special-education-evaluations?Culture=en",
    ]
    out = asyncio.run(scrape_many(test_urls))
    print(json.dumps(out, indent=2, ensure_ascii=False))
