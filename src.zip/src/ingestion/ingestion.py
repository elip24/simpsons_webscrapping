# src/ingestion/ingest.py
import asyncio
import json
from asyncio import Semaphore
from datetime import datetime, date

import httpx
from src.ingestion.concurrency_utils import process_with_semaphore
from src.ingestion.get_url_request import get_url_request
from src.ingestion.news_only import get_news_articles_async, warm_cookies_httpx

MAX_CONCURRENT_REQUESTS = 3

def _default_json(o):
    if isinstance(o, (datetime, date)):
        return o.isoformat()
    return str(o)

async def main_news(ndjson_path: str = "all_news_added.ndjson"):
    deduped_urls, all_metadata= get_url_request()
    semaphore = Semaphore(MAX_CONCURRENT_REQUESTS)

    async with httpx.AsyncClient(follow_redirects=True) as client:
        await warm_cookies_httpx(client)

        tasks = [
            process_with_semaphore(
                client=client,
                start_url=meta["url"],
                semaphore=semaphore,
                extractor_function=get_news_articles_async,
                meta=meta,
            )
            for meta in all_metadata
        ]

        results = []
        for coro in asyncio.as_completed(tasks):
            try:
                rec = await coro
                if rec:
                    results.append(rec)
            except Exception as e:
                print(f"Failed to extract news: {e}")

    with open(ndjson_path, "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False, default=_default_json))
            f.write("\n")

def ingestion():
    asyncio.run(main_news())

if __name__ == "__main__":
    ingestion()
