import re
from datetime import datetime, timezone
from typing import Iterable, Tuple, List, Dict, Set
from urllib.parse import urljoin

from src.ingestion.page_configurations import suffix, prefix


def parse_publicationdate(s:str) ->datetime:
    ms= int(re.search(r"\d+", s).group())
    return datetime.fromtimestamp(ms/1000,tz=timezone.utc)

def build_url(url):
    return prefix+url+ suffix

def get_urls_and_dates(response):
    results = [
        {
            "id":row["Id"],
            "headline": row["Title"],
            "url": build_url(row["Url"]),
            "publicationDate": parse_publicationdate(row["PublicationDate"]),
            "NewsTypeGuid":row["NewsTypeGuid"],
        }
        for row in response
    ]
    return results
