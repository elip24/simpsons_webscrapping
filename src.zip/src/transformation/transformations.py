import os, json
import polars as pl

ROOT_PATH = os.getcwd()
file_path = os.path.join(ROOT_PATH, "all_news.ndjson")

records = []
with open(file_path, "r", encoding="utf-8") as f:
    for ln, line in enumerate(f, start=1):
        s = line.strip()
        if not s:
            continue
        try:
            records.append(json.loads(s))
        except json.JSONDecodeError as e:
            print(f"[NDJSON] Línea {ln} inválida: {e}. Fragmento: {s[:120]!r}")

file_path = os.path.join(ROOT_PATH, "all_news_added.ndjson")

df = pl.DataFrame(records)



records = []
with open(file_path, "r", encoding="utf-8") as f:
    for ln, line in enumerate(f, start=1):
        s = line.strip()
        if not s:
            continue
        try:
            records.append(json.loads(s))
        except json.JSONDecodeError as e:
            print(f"[NDJSON] Línea {ln} inválida: {e}. Fragmento: {s[:120]!r}")
df_2 = pl.DataFrame(records)
file_path = os.path.join(ROOT_PATH, "all_news_final.ndjson")

records = []
with open(file_path, "r", encoding="utf-8") as f:
    for ln, line in enumerate(f, start=1):
        s = line.strip()
        if not s:
            continue
        try:
            records.append(json.loads(s))
        except json.JSONDecodeError as e:
            print(f"[NDJSON] Línea {ln} inválida: {e}. Fragmento: {s[:120]!r}")
df_3 = pl.DataFrame(records)

file_path = os.path.join(ROOT_PATH, "all_news_added_v4.ndjson")

records = []
with open(file_path, "r", encoding="utf-8") as f:
    for ln, line in enumerate(f, start=1):
        s = line.strip()
        if not s:
            continue
        try:
            records.append(json.loads(s))
        except json.JSONDecodeError as e:
            print(f"[NDJSON] Línea {ln} inválida: {e}. Fragmento: {s[:120]!r}")
df_4 = pl.DataFrame(records)

df=pl.concat([df,df_2,df_3,df_4])
df=df.filter(pl.col("text")!="").select(pl.col("url"))
row_count_shape = df.height
df=df.unique('url')
df.write_csv('all_urls.csv')